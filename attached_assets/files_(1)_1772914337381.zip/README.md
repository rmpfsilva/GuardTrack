# GuardTrack — AI Brand Colour Extraction

Extends the per-company branding system with Claude-powered automatic colour
extraction from a company's website.

---

## How it works

```
Rick enters: https://apexsecurity.co.uk
        ↓
Server fetches the homepage HTML
        ↓
Extracts: hex/rgb/hsl colours from CSS, meta theme-color, og:image URL
        ↓
Fetches og:image → base64 (for Claude Vision)
        ↓
Sends to claude-sonnet-4-20250514:
  - The extracted colour list
  - The raw CSS snippet (first 3000 chars)
  - The og:image (if found) for visual analysis
        ↓
Claude returns JSON:
  {
    recommended: { hex, name, reason },
    palette: [{ hex, name, usage }, ...],
    brandNotes: "..."
  }
        ↓
UI shows AI-recommended colour pre-selected
Rick can override with any colour from the palette
Clicks Save → stored in DB → theme applies on next login
```

---

## Files in this package

| File | Where it goes | What it does |
|------|--------------|--------------|
| `branding-ai.route.ts` | `server/routes/` | The AI analysis endpoint |
| `BrandingSettings.tsx` | `client/src/components/admin/` | Updated UI with AI analyse panel |

These **replace/extend** the files from the initial branding package.
The SQL migration and `useCompanyTheme` hook from the first package are unchanged.

---

## Server setup

### 1. Register the route

In your `server/index.ts` or main router file:

```typescript
import brandingAiRouter from "./routes/branding-ai";

// Add alongside your existing routes
app.use("/api", brandingAiRouter);
```

### 2. Environment variable

Make sure `ANTHROPIC_API_KEY` is set in your `.env`:

```
ANTHROPIC_API_KEY=sk-ant-...
```

### 3. Install Anthropic SDK (if not already)

```bash
npm install @anthropic-ai/sdk
```

---

## What Claude analyses

| Source | What's extracted |
|--------|-----------------|
| CSS `<style>` blocks | All hex, rgb(), hsl() values |
| Inline styles | Same colour formats |
| `<meta name="theme-color">` | Primary OS-level brand colour |
| `og:image` | Fetched and sent to Claude Vision for visual brand analysis |

Colours that are near-black, near-white, or near-grey are automatically
filtered out before being sent to Claude — only meaningful brand colours reach the AI.

---

## Claude's selection criteria

Claude is instructed to recommend a colour that:
- Is clearly the company's **primary brand colour**
- Works on **both light (main content) and dark (sidebar)** backgrounds
- Is not too light (avoids HSL lightness > 70%)
- Feels **professional and trustworthy** for the security industry

---

## Fallback behaviour

| Scenario | Behaviour |
|----------|-----------|
| Website times out (>12s) | Returns 408 with user-friendly message |
| og:image not found | Analysis proceeds with CSS colours only |
| No colours in CSS | Claude uses og:image only |
| Claude returns invalid JSON | Returns 500, user can retry |
| User doesn't want AI | Full manual colour picker still available |

---

## Security notes

- Only `super_admin` role can call the analyse endpoint
- URL is validated and normalised before fetching
- The server fetches the external website (not the client browser), so no CORS issues
- og:image is fetched server-side and converted to base64 — the client never touches external URLs
