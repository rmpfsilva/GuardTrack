// components/admin/BrandingSettings.tsx  (UPDATED — replaces previous version)
// Now includes AI-powered website colour extraction.
//
// New flow:
//   1. Rick enters the company website URL
//   2. Clicks "Analyse with AI"
//   3. AI scrapes the site + uses Claude Vision on og:image
//   4. Returns recommended colour + full brand palette with reasoning
//   5. Recommended colour is pre-selected; Rick can pick any from the palette
//   6. Saves as before

import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Palette, Check, RotateCcw, Globe, Sparkles,
  Loader2, ChevronRight, AlertCircle, Info
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

// ── Types ─────────────────────────────────────────────────────────────────

interface PaletteColour {
  hex: string;
  name: string;
  usage: string;
}

interface AIBrandingResult {
  recommended: {
    hex: string;
    name: string;
    reason: string;
  };
  palette: PaletteColour[];
  brandNotes: string;
  siteTitle: string | null;
}

// ── Zod schemas ───────────────────────────────────────────────────────────

const brandingSchema = z.object({
  brand_colour: z
    .string()
    .regex(/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/, "Must be a valid hex colour (#rrggbb)"),
});
type BrandingForm = z.infer<typeof brandingSchema>;

const urlSchema = z.object({
  website_url: z.string().min(3, "Enter a website URL"),
});
type UrlForm = z.infer<typeof urlSchema>;

// ── Preset colours for manual selection ──────────────────────────────────

const PRESET_COLOURS = [
  { label: "GT Blue",  hex: "#2563eb" },
  { label: "Slate",    hex: "#475569" },
  { label: "Red",      hex: "#dc2626" },
  { label: "Green",    hex: "#16a34a" },
  { label: "Orange",   hex: "#ea580c" },
  { label: "Purple",   hex: "#7c3aed" },
  { label: "Teal",     hex: "#0d9488" },
  { label: "Rose",     hex: "#e11d48" },
  { label: "Indigo",   hex: "#4338ca" },
  { label: "Amber",    hex: "#d97706" },
];

// ── Props ─────────────────────────────────────────────────────────────────

interface BrandingSettingsProps {
  companyId: number;
  companyName: string;
  currentColour: string | null;
  websiteUrl?: string | null;
}

// ── Component ─────────────────────────────────────────────────────────────

export function BrandingSettings({
  companyId,
  companyName,
  currentColour,
  websiteUrl,
}: BrandingSettingsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [preview, setPreview]           = useState<string>(currentColour ?? "#2563eb");
  const [aiResult, setAiResult]         = useState<AIBrandingResult | null>(null);
  const [selectedPalette, setSelected]  = useState<string | null>(null);
  const [analysisError, setError]       = useState<string | null>(null);

  // ── Colour save form ──────────────────────────────────────────────────
  const {
    register, handleSubmit, setValue, watch,
    formState: { errors },
  } = useForm<BrandingForm>({
    resolver: zodResolver(brandingSchema),
    defaultValues: { brand_colour: currentColour ?? "#2563eb" },
  });

  const colour = watch("brand_colour");

  // ── URL form ──────────────────────────────────────────────────────────
  const {
    register: registerUrl,
    handleSubmit: handleUrlSubmit,
    formState: { errors: urlErrors },
  } = useForm<UrlForm>({
    resolver: zodResolver(urlSchema),
    defaultValues: { website_url: websiteUrl ?? "" },
  });

  // ── Save branding mutation ────────────────────────────────────────────
  const saveMutation = useMutation({
    mutationFn: async (data: BrandingForm) => {
      const res = await fetch(`/api/admin/companies/${companyId}/branding`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error ?? "Failed to update branding");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["companies", companyId] });
      queryClient.invalidateQueries({ queryKey: ["auth", "me"] });
      toast({
        title: "Branding saved",
        description: `${companyName}'s brand colour has been updated.`,
      });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  // ── AI analyse mutation ───────────────────────────────────────────────
  const analyseMutation = useMutation({
    mutationFn: async (data: UrlForm) => {
      const res = await fetch(`/api/admin/companies/${companyId}/branding/analyse`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error ?? "Analysis failed");
      }
      return res.json() as Promise<AIBrandingResult>;
    },
    onSuccess: (data) => {
      setAiResult(data);
      setError(null);
      // Pre-select the AI recommended colour
      applyColour(data.recommended.hex);
      setSelected(data.recommended.hex);
      toast({
        title: "AI analysis complete",
        description: `Found ${data.palette.length} brand colours for ${data.siteTitle ?? companyName}.`,
      });
    },
    onError: (err: Error) => {
      setError(err.message);
      setAiResult(null);
    },
  });

  // ── Helpers ───────────────────────────────────────────────────────────

  function applyColour(hex: string) {
    setValue("brand_colour", hex, { shouldValidate: true });
    setPreview(hex);
  }

  function selectPreset(hex: string) {
    applyColour(hex);
    setSelected(null); // clear palette selection when using presets
  }

  function selectPaletteColour(hex: string) {
    applyColour(hex);
    setSelected(hex);
  }

  function onSave(data: BrandingForm) {
    saveMutation.mutate(data);
  }

  function onAnalyse(data: UrlForm) {
    setAiResult(null);
    setError(null);
    analyseMutation.mutate(data);
  }

  // ── Render ────────────────────────────────────────────────────────────

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Palette className="w-4 h-4" />
          Company Branding
        </CardTitle>
        <CardDescription>
          Set a brand colour for <strong>{companyName}</strong>. Use AI to automatically
          extract colours from their website, or pick manually.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">

        {/* ── Live Preview ── */}
        <div
          className="rounded-xl p-4 flex items-center gap-4 border transition-all duration-300"
          style={{
            background: `linear-gradient(135deg, ${preview}22 0%, ${preview}08 100%)`,
            borderColor: `${preview}44`,
          }}
        >
          <div
            className="w-12 h-12 rounded-xl flex-shrink-0 shadow-lg transition-all duration-300"
            style={{ background: preview, boxShadow: `0 4px 16px ${preview}55` }}
          />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-foreground">{companyName}</p>
            <p className="text-xs text-muted-foreground">Dashboard theme preview</p>
            <p className="text-xs font-mono mt-1" style={{ color: preview }}>{preview}</p>
          </div>
          <div className="flex gap-2 flex-shrink-0">
            <div
              className="px-3 py-1 rounded-full text-xs font-semibold text-white transition-all duration-300"
              style={{ background: preview }}
            >
              Button
            </div>
            <div
              className="px-3 py-1 rounded-full text-xs font-semibold transition-all duration-300"
              style={{
                background: `${preview}22`,
                color: preview,
                border: `1px solid ${preview}44`,
              }}
            >
              Badge
            </div>
          </div>
        </div>

        {/* ── AI Website Analysis ── */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <Label className="text-sm font-semibold">AI Colour Extraction</Label>
            <Badge variant="secondary" className="text-[10px] px-1.5 py-0">BETA</Badge>
          </div>

          <form onSubmit={handleUrlSubmit(onAnalyse)} className="flex gap-2">
            <div className="flex-1 relative">
              <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="https://apexsecurity.co.uk"
                className="pl-9 font-mono text-sm"
                {...registerUrl("website_url")}
              />
            </div>
            <Button
              type="submit"
              variant="outline"
              disabled={analyseMutation.isPending}
              className="flex-shrink-0 gap-2"
            >
              {analyseMutation.isPending ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Analysing...</>
              ) : (
                <><Sparkles className="w-4 h-4" /> Analyse</>
              )}
            </Button>
          </form>
          {urlErrors.website_url && (
            <p className="text-xs text-destructive">{urlErrors.website_url.message}</p>
          )}

          {/* Analysis error */}
          {analysisError && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-sm text-destructive">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <p>{analysisError}</p>
            </div>
          )}

          {/* AI Results */}
          {aiResult && (
            <div className="space-y-3 rounded-xl border bg-muted/30 p-4">

              {/* Brand notes */}
              <div className="flex items-start gap-2 text-xs text-muted-foreground">
                <Info className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-amber-500" />
                <span><strong className="text-foreground">AI:</strong> {aiResult.brandNotes}</span>
              </div>

              <Separator />

              {/* Recommended */}
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  AI Recommendation
                </p>
                <button
                  type="button"
                  onClick={() => selectPaletteColour(aiResult.recommended.hex)}
                  className={cn(
                    "w-full flex items-center gap-3 p-3 rounded-lg border-2 transition-all text-left",
                    selectedPalette === aiResult.recommended.hex
                      ? "border-current shadow-sm"
                      : "border-transparent bg-background hover:border-muted-foreground/30"
                  )}
                  style={
                    selectedPalette === aiResult.recommended.hex
                      ? { borderColor: aiResult.recommended.hex }
                      : {}
                  }
                >
                  <div
                    className="w-10 h-10 rounded-lg flex-shrink-0 shadow"
                    style={{ background: aiResult.recommended.hex }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold">{aiResult.recommended.name}</span>
                      <span className="font-mono text-xs text-muted-foreground">
                        {aiResult.recommended.hex}
                      </span>
                      <Badge className="text-[10px] px-1.5 py-0 ml-auto" style={{
                        background: `${aiResult.recommended.hex}22`,
                        color: aiResult.recommended.hex,
                        border: `1px solid ${aiResult.recommended.hex}44`
                      }}>
                        Recommended
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                      {aiResult.recommended.reason}
                    </p>
                  </div>
                  {selectedPalette === aiResult.recommended.hex && (
                    <Check className="w-4 h-4 flex-shrink-0" style={{ color: aiResult.recommended.hex }} />
                  )}
                </button>
              </div>

              {/* Full palette */}
              {aiResult.palette.filter(p => p.hex !== aiResult.recommended.hex).length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                    Other brand colours
                  </p>
                  <div className="space-y-1.5">
                    {aiResult.palette
                      .filter(p => p.hex !== aiResult.recommended.hex)
                      .map((c) => (
                        <button
                          key={c.hex}
                          type="button"
                          onClick={() => selectPaletteColour(c.hex)}
                          className={cn(
                            "w-full flex items-center gap-3 p-2.5 rounded-lg border transition-all text-left",
                            selectedPalette === c.hex
                              ? "border-2"
                              : "border-transparent bg-background hover:border-muted-foreground/20"
                          )}
                          style={selectedPalette === c.hex ? { borderColor: c.hex } : {}}
                        >
                          <div
                            className="w-7 h-7 rounded-md flex-shrink-0 shadow-sm"
                            style={{ background: c.hex }}
                          />
                          <div className="flex-1 min-w-0">
                            <span className="text-sm font-medium">{c.name}</span>
                            <span className="font-mono text-xs text-muted-foreground ml-2">{c.hex}</span>
                            <p className="text-xs text-muted-foreground truncate">{c.usage}</p>
                          </div>
                          {selectedPalette === c.hex
                            ? <Check className="w-3.5 h-3.5 flex-shrink-0" style={{ color: c.hex }} />
                            : <ChevronRight className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                          }
                        </button>
                      ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        <Separator />

        {/* ── Manual colour entry ── */}
        <div className="space-y-4">
          <Label className="text-sm font-semibold">Manual Selection</Label>

          {/* Preset swatches */}
          <div>
            <p className="text-xs text-muted-foreground mb-2">Quick presets</p>
            <div className="flex flex-wrap gap-2">
              {PRESET_COLOURS.map((p) => (
                <button
                  key={p.hex}
                  type="button"
                  onClick={() => selectPreset(p.hex)}
                  title={p.label}
                  className="w-8 h-8 rounded-lg border-2 transition-all duration-150 hover:scale-110 focus:outline-none"
                  style={{
                    background: p.hex,
                    borderColor: colour === p.hex ? "white" : "transparent",
                    boxShadow: colour === p.hex ? `0 0 0 2px ${p.hex}` : "none",
                  }}
                >
                  {colour === p.hex && (
                    <Check className="w-3 h-3 text-white mx-auto" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Hex input + native picker */}
          <form onSubmit={handleSubmit(onSave)}>
            <div className="flex gap-3 items-end mb-4">
              <div className="flex-1">
                <Label htmlFor="brand_colour">Hex colour code</Label>
                <Input
                  id="brand_colour"
                  placeholder="#2563eb"
                  {...register("brand_colour")}
                  onChange={(e) => {
                    register("brand_colour").onChange(e);
                    const val = e.target.value;
                    if (/^#[0-9a-fA-F]{6}$/.test(val) || /^#[0-9a-fA-F]{3}$/.test(val)) {
                      setPreview(val);
                    }
                  }}
                  className="font-mono"
                />
                {errors.brand_colour && (
                  <p className="text-xs text-destructive mt-1">{errors.brand_colour.message}</p>
                )}
              </div>
              <div>
                <Label className="block mb-1 text-xs text-muted-foreground">Picker</Label>
                <input
                  type="color"
                  value={preview}
                  onChange={(e) => {
                    applyColour(e.target.value);
                    setSelected(null);
                  }}
                  className="w-10 h-10 rounded-lg border border-input cursor-pointer p-0.5"
                />
              </div>
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => { selectPreset("#2563eb"); setSelected(null); }}
                title="Reset to GuardTrack default"
              >
                <RotateCcw className="w-4 h-4" />
              </Button>
            </div>

            <Button
              type="submit"
              disabled={saveMutation.isPending || !!errors.brand_colour}
              className="w-full transition-all duration-300 text-white"
              style={{ background: preview, boxShadow: `0 4px 14px ${preview}55` }}
            >
              {saveMutation.isPending ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
              ) : (
                "Save Brand Colour"
              )}
            </Button>
          </form>
        </div>

      </CardContent>
    </Card>
  );
}
