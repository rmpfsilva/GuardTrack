// server/routes/branding-ai.ts
// POST /api/admin/companies/:id/branding/analyse
//
// Flow:
//   1. Receive a website URL from the client
//   2. Fetch the raw HTML of the homepage
//   3. Extract colour hints from CSS, inline styles, meta tags, and og:image
//   4. Send all of this context to Claude (claude-sonnet-4-20250514) with vision if image available
//   5. Claude returns a structured JSON: recommended colour + full palette with reasoning
//   6. Return to client for Rick to review and apply

import { Router, Request, Response } from "express";
import Anthropic from "@anthropic-ai/sdk";

const router = Router();
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ── Helpers ───────────────────────────────────────────────────────────────

/**
 * Fetches a webpage and extracts colour-relevant content:
 * - All hex/rgb/hsl colour values found in <style> tags and inline styles
 * - Meta theme-color
 * - og:image URL (for visual analysis)
 * - Brand-related class names and text (logo, header, nav)
 */
async function extractWebsiteColourData(url: string): Promise<{
  colours: string[];
  themeColor: string | null;
  ogImageUrl: string | null;
  siteTitle: string | null;
  rawCssSnippet: string;
}> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);

  let html: string;
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; GuardTrack-BrandBot/1.0)",
        "Accept": "text/html,application/xhtml+xml",
      },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    html = await res.text();
  } finally {
    clearTimeout(timeout);
  }

  // Extract colour values from CSS
  const hexColours   = [...html.matchAll(/#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b/g)].map(m => m[0]);
  const rgbColours   = [...html.matchAll(/rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\)/g)].map(m => m[0]);
  const hslColours   = [...html.matchAll(/hsl\(\s*\d+\s*,\s*[\d.]+%\s*,\s*[\d.]+%\s*\)/g)].map(m => m[0]);

  // Deduplicate, filter out blacks/whites/greys (unlikely to be brand colours)
  const allColours = [...new Set([...hexColours, ...rgbColours, ...hslColours])];
  const filtered = allColours.filter(c => {
    if (c.startsWith('#')) {
      const hex = c.replace('#', '');
      const full = hex.length === 3
        ? hex.split('').map(x => x+x).join('')
        : hex;
      const r = parseInt(full.slice(0,2), 16);
      const g = parseInt(full.slice(2,4), 16);
      const b = parseInt(full.slice(4,6), 16);
      // Filter near-black, near-white, near-grey
      const isGrey = Math.abs(r-g) < 20 && Math.abs(g-b) < 20 && Math.abs(r-b) < 20;
      const isBlack = r < 30 && g < 30 && b < 30;
      const isWhite = r > 225 && g > 225 && b > 225;
      return !isGrey && !isBlack && !isWhite;
    }
    return true;
  });

  // meta theme-color
  const themeMatch = html.match(/<meta[^>]+name=["']theme-color["'][^>]+content=["']([^"']+)["']/i)
    || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+name=["']theme-color["']/i);
  const themeColor = themeMatch ? themeMatch[1].trim() : null;

  // og:image
  const ogMatch = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)
    || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i);
  const ogImageUrl = ogMatch ? ogMatch[1].trim() : null;

  // site title
  const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
  const siteTitle = titleMatch ? titleMatch[1].trim() : null;

  // Raw CSS snippet (first 3000 chars of style blocks for Claude context)
  const cssBlocks = [...html.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/gi)].map(m => m[1]);
  const rawCssSnippet = cssBlocks.join('\n').slice(0, 3000);

  return {
    colours: filtered.slice(0, 40), // cap at 40 to stay within token budget
    themeColor,
    ogImageUrl,
    siteTitle,
    rawCssSnippet,
  };
}

/**
 * Fetch an image URL and return it as base64 for Claude Vision.
 */
async function fetchImageAsBase64(imageUrl: string): Promise<{ data: string; mediaType: string } | null> {
  try {
    const res = await fetch(imageUrl, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    const contentType = res.headers.get("content-type") ?? "image/jpeg";
    const mediaType = contentType.split(";")[0].trim();
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
    if (!allowedTypes.includes(mediaType)) return null;
    const buffer = await res.arrayBuffer();
    const data = Buffer.from(buffer).toString("base64");
    return { data, mediaType };
  } catch {
    return null;
  }
}

// ── Route ─────────────────────────────────────────────────────────────────

router.post("/admin/companies/:id/branding/analyse", async (req: Request, res: Response) => {
  // Guard: super admin only
  if ((req.session as any)?.role !== "super_admin") {
    return res.status(403).json({ error: "Forbidden" });
  }

  const { website_url } = req.body as { website_url: string };

  if (!website_url) {
    return res.status(400).json({ error: "website_url is required" });
  }

  // Normalise URL
  let url: string;
  try {
    const parsed = new URL(
      website_url.startsWith("http") ? website_url : `https://${website_url}`
    );
    url = parsed.toString();
  } catch {
    return res.status(400).json({ error: "Invalid URL" });
  }

  try {
    // Step 1: Extract colour data from the website
    const siteData = await extractWebsiteColourData(url);

    // Step 2: Try to get the og:image for visual analysis
    let imageContent: Anthropic.ImageBlockParam | null = null;
    if (siteData.ogImageUrl) {
      const imgData = await fetchImageAsBase64(siteData.ogImageUrl);
      if (imgData) {
        imageContent = {
          type: "image",
          source: {
            type: "base64",
            media_type: imgData.mediaType as "image/jpeg" | "image/png" | "image/gif" | "image/webp",
            data: imgData.data,
          },
        };
      }
    }

    // Step 3: Build Claude prompt
    const systemPrompt = `You are a brand colour analyst for GuardTrack, a professional B2B SaaS platform 
used by security companies. Your job is to analyse a company's website and extract their brand colours,
then recommend the single best colour to use as a UI theme colour in a dark-sidebar enterprise dashboard.

A good dashboard theme colour must:
- Be clearly identifiable as the company's primary brand colour
- Have sufficient contrast to work on both white backgrounds (main content) and dark backgrounds (sidebar)
- Not be too light (avoid colours lighter than HSL lightness 70%) 
- Not be near-black or near-grey
- Feel professional and trustworthy for a security/operations industry context

Respond ONLY with a valid JSON object. No markdown, no explanation outside the JSON.

Required JSON structure:
{
  "recommended": {
    "hex": "#xxxxxx",
    "name": "Short colour name",
    "reason": "1-2 sentence explanation of why this is the best choice for their dashboard"
  },
  "palette": [
    { "hex": "#xxxxxx", "name": "Colour name", "usage": "Where this colour appears on their site" },
    { "hex": "#xxxxxx", "name": "Colour name", "usage": "Where this colour appears on their site" }
  ],
  "brandNotes": "1 sentence summary of the company's overall brand aesthetic"
}

The palette should contain 3-6 colours total (including the recommended one).
Only include distinct, meaningful brand colours — not whites, blacks, or greys.`;

    const userContent: Anthropic.MessageParam["content"] = [];

    if (imageContent) {
      userContent.push(imageContent);
    }

    userContent.push({
      type: "text",
      text: `Analyse the brand colours for this website: ${url}
Site title: ${siteData.siteTitle ?? "Unknown"}
${siteData.themeColor ? `Meta theme-color: ${siteData.themeColor}` : ""}

Colours extracted from their CSS and styles:
${siteData.colours.length > 0 ? siteData.colours.join(", ") : "None extracted"}

CSS snippet for context:
${siteData.rawCssSnippet || "Not available"}

${imageContent ? "I've also included their og:image above for visual analysis." : ""}

Based on all of this, identify their brand palette and recommend the best single colour for a GuardTrack dashboard theme.`,
    });

    // Step 4: Call Claude
    const claudeResponse = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: systemPrompt,
      messages: [{ role: "user", content: userContent }],
    });

    const rawText = claudeResponse.content
      .filter(b => b.type === "text")
      .map(b => (b as Anthropic.TextBlock).text)
      .join("");

    // Step 5: Parse and return
    const clean = rawText.replace(/```json|```/g, "").trim();
    const result = JSON.parse(clean);

    return res.json({
      success: true,
      url,
      siteTitle: siteData.siteTitle,
      ...result,
    });

  } catch (err: any) {
    console.error("[branding/analyse]", err);

    if (err.name === "AbortError" || err.code === "UND_ERR_CONNECT_TIMEOUT") {
      return res.status(408).json({ error: "Website took too long to respond. Try again or enter a colour manually." });
    }
    if (err instanceof SyntaxError) {
      return res.status(500).json({ error: "AI response could not be parsed. Please try again." });
    }

    return res.status(500).json({ error: err.message ?? "Analysis failed" });
  }
});

export default router;
