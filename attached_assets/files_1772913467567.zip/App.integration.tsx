// App.tsx — example of where to call useCompanyTheme
// This shows the integration pattern. Adapt to match your existing App.tsx structure.

import { useCompanyTheme } from "@/hooks/useCompanyTheme";
import { useQuery } from "@tanstack/react-query";

// ── Fetch the current session / auth user ──────────────────────────────────
// Adjust the shape of `data` to match what your /api/auth/me endpoint returns.
interface AuthUser {
  id: number;
  name: string;
  role: string;
  company: {
    id: number;
    name: string;
    brand_colour: string | null;  // ← the new field
  };
}

function useAuthUser() {
  return useQuery<AuthUser>({
    queryKey: ["auth", "me"],
    queryFn: async () => {
      const res = await fetch("/api/auth/me", { credentials: "include" });
      if (!res.ok) throw new Error("Not authenticated");
      return res.json();
    },
    staleTime: 1000 * 60 * 5, // 5 min — session data doesn't change often
    retry: false,
  });
}

// ── ThemeProvider — sits at the top of your app tree ──────────────────────
// Extract this into its own component so theming is applied before children render.
function ThemeProvider({ children }: { children: React.ReactNode }) {
  const { data: authUser } = useAuthUser();

  // Apply company theme whenever the authenticated user changes.
  // Falls back to GuardTrack default blue if brand_colour is null.
  useCompanyTheme(authUser?.company?.brand_colour);

  return <>{children}</>;
}

// ── Your existing App component ────────────────────────────────────────────
// Wrap your router/layout in ThemeProvider:

export default function App() {
  return (
    <ThemeProvider>
      {/* Your existing router, layout, routes go here */}
      {/* e.g. <Router> ... </Router> */}
    </ThemeProvider>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PLATFORM ADMIN NOTE:
// If you're a super-admin viewing multiple companies (like Rick's admin panel),
// you may want to apply the theme of the currently *viewed* company rather than
// the logged-in user's company. In that case, pass the selected company's
// brand_colour to useCompanyTheme from your company selection state instead.
// ─────────────────────────────────────────────────────────────────────────────
