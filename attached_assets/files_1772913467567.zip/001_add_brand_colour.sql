-- Migration: Add brand_colour to companies table
-- Run this against your PostgreSQL database

ALTER TABLE companies
  ADD COLUMN IF NOT EXISTS brand_colour VARCHAR(7) DEFAULT '#2563eb';

-- Optional: add a comment for clarity
COMMENT ON COLUMN companies.brand_colour IS 'Hex colour code for per-company UI theming (e.g. #2563eb)';

-- If your table is named "clients" instead of "companies", use:
-- ALTER TABLE clients ADD COLUMN IF NOT EXISTS brand_colour VARCHAR(7) DEFAULT '#2563eb';
