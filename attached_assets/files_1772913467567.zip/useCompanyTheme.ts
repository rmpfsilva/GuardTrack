// hooks/useCompanyTheme.ts
// Converts a hex brand colour into HSL CSS variables and injects them
// at the document root so all components pick them up automatically.

import { useEffect } from "react";

/**
 * Converts a hex colour string (#rrggbb or #rgb) to { h, s, l } values.
 */
function hexToHsl(hex: string): { h: number; s: number; l: number } | null {
  // Expand shorthand #rgb → #rrggbb
  const full = hex.replace(/^#([a-f\d])([a-f\d])([a-f\d])$/i, (_, r, g, b) =>
    `#${r}${r}${g}${g}${b}${b}`
  );

  const result = /^#([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(full);
  if (!result) return null;

  let r = parseInt(result[1], 16) / 255;
  let g = parseInt(result[2], 16) / 255;
  let b = parseInt(result[3], 16) / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const delta = max - min;

  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (delta !== 0) {
    s = delta / (1 - Math.abs(2 * l - 1));
    switch (max) {
      case r: h = ((g - b) / delta + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / delta + 2) / 6; break;
      case b: h = ((r - g) / delta + 4) / 6; break;
    }
  }

  return {
    h: Math.round(h * 360),
    s: Math.round(s * 100),
    l: Math.round(l * 100),
  };
}

/**
 * Injects company brand CSS variables onto :root.
 * Call once at the App level after auth resolves.
 *
 * Variables set:
 *   --brand-h, --brand-s, --brand-l        → raw HSL components
 *   --brand                                 → hsl(h s% l%)
 *   --brand-dark                            → darker shade (for text/borders)
 *   --brand-light                           → very light tint (for backgrounds)
 *   --brand-mid                             → mid shade (for secondary elements)
 *   --brand-glow                            → low-opacity version (for shadows/glows)
 *   --brand-glow-strong                     → medium-opacity version
 */
export function useCompanyTheme(brandColour: string | null | undefined) {
  useEffect(() => {
    const root = document.documentElement;

    // Fallback to GuardTrack's default blue if no colour set
    const colour = brandColour ?? "#2563eb";
    const hsl = hexToHsl(colour);

    if (!hsl) {
      console.warn(`[useCompanyTheme] Invalid colour: "${colour}", using default.`);
      return;
    }

    const { h, s, l } = hsl;

    root.style.setProperty("--brand-h", String(h));
    root.style.setProperty("--brand-s", `${s}%`);
    root.style.setProperty("--brand-l", `${l}%`);

    root.style.setProperty("--brand",             `hsl(${h} ${s}% ${l}%)`);
    root.style.setProperty("--brand-dark",         `hsl(${h} ${s}% ${Math.max(l - 20, 10)}%)`);
    root.style.setProperty("--brand-light",        `hsl(${h} ${Math.round(s * 0.4)}% 94%)`);
    root.style.setProperty("--brand-mid",          `hsl(${h} ${s}% ${Math.min(l + 15, 75)}%)`);
    root.style.setProperty("--brand-glow",         `hsl(${h} ${s}% ${l}% / 0.15)`);
    root.style.setProperty("--brand-glow-strong",  `hsl(${h} ${s}% ${l}% / 0.30)`);
  }, [brandColour]);
}
