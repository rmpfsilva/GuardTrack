# GuardTrack — Per-Company Branding

Implement per-company colour theming across the entire GuardTrack dashboard.
Each company gets a unique brand colour that flows through the sidebar, topbar,
buttons, badges, cards, and background — while GuardTrack's identity stays visible.

---

## Files in this package

| File | Where it goes | What it does |
|------|--------------|--------------|
| `001_add_brand_colour.sql` | Run against your DB | Adds `brand_colour` column to `companies` table |
| `useCompanyTheme.ts` | `client/src/hooks/` | Converts hex → HSL, injects CSS variables at `:root` |
| `tailwind.config.additions.ts` | Merge into `tailwind.config.ts` | Adds `bg-brand`, `text-brand`, etc. as Tailwind classes |
| `App.integration.tsx` | Merge into `App.tsx` | Calls `useCompanyTheme` once at app root after auth loads |
| `server.auth.additions.ts` | Merge into your auth route | Returns `brand_colour` in `/api/auth/me`; adds PATCH endpoint |
| `BrandingSettings.tsx` | `client/src/components/admin/` | Colour picker UI for the Platform Admin panel |

---

## Integration order

### Step 1 — Database
```sql
-- Run 001_add_brand_colour.sql against your PostgreSQL database
ALTER TABLE companies ADD COLUMN IF NOT EXISTS brand_colour VARCHAR(7) DEFAULT '#2563eb';
```

### Step 2 — Hook
Copy `useCompanyTheme.ts` → `client/src/hooks/useCompanyTheme.ts`

### Step 3 — Tailwind config
Open your `tailwind.config.ts` and merge the `colors`, `boxShadow`, and
`backgroundImage` additions from `tailwind.config.additions.ts` into your
existing `theme.extend` block.

### Step 4 — Backend
In your auth route file, update your `GET /api/auth/me` query to include
`brand_colour` from the companies join. Add the `PATCH /api/admin/companies/:id/branding`
endpoint so the Platform Admin can set colours.

### Step 5 — App.tsx
Wrap your existing router/layout in `<ThemeProvider>` as shown in
`App.integration.tsx`. The theme applies automatically after auth resolves.

### Step 6 — Admin UI
Drop `<BrandingSettings>` into your existing company detail/edit page
in the Platform Admin panel. Pass `companyId`, `companyName`, and `currentColour`.

```tsx
<BrandingSettings
  companyId={company.id}
  companyName={company.name}
  currentColour={company.brand_colour}
/>
```

---

## How it works

```
DB: companies.brand_colour = "#dc2626"
         ↓
/api/auth/me → { company: { brand_colour: "#dc2626" } }
         ↓
useCompanyTheme("#dc2626") → hexToHsl() → { h: 0, s: 72, l: 42 }
         ↓
document.documentElement.style:
  --brand:            hsl(0 72% 42%)
  --brand-dark:       hsl(0 72% 22%)
  --brand-light:      hsl(0 29% 94%)
  --brand-mid:        hsl(0 72% 57%)
  --brand-glow:       hsl(0 72% 42% / 0.15)
  --brand-glow-strong:hsl(0 72% 42% / 0.30)
         ↓
Tailwind: bg-brand → background: var(--brand) ✓
CSS:      border-color: var(--brand-dark)      ✓
```

---

## Using brand classes in your components

Replace any hardcoded blue Tailwind classes with brand equivalents:

```tsx
// Before
<Button className="bg-blue-600 hover:bg-blue-700 shadow-blue-200">

// After
<Button className="bg-brand hover:brightness-110 shadow-brand">
```

```tsx
// Sidebar active item
<div className="bg-brand-glow border border-brand/30 text-white">

// Card accent top border
<div className="border-t-2 border-t-brand">

// Badge
<span className="bg-brand-light text-brand-dark border border-brand/20">

// Page background wash
<div className="bg-brand-wash min-h-screen">
```

---

## Notes

- **Super Admin view**: When Rick views a specific company in the Platform Admin,
  you can optionally apply that company's theme by passing their `brand_colour`
  to `useCompanyTheme` from your selected-company state rather than auth user.

- **Default colour**: If `brand_colour` is null, the hook falls back to `#2563eb`
  (GuardTrack's default blue). No company ever sees a broken/unthemed UI.

- **No performance cost**: CSS variables are inherited natively by the browser.
  There's zero re-render overhead — only the `:root` style attribute changes.
