// server/routes/auth.ts — additions to your existing auth/me endpoint
// Shows how to include brand_colour in the session response.
// Adapt the query to match your actual schema and ORM/query style.

import { Router } from "express";
import { db } from "../db"; // your drizzle/pg client

const router = Router();

// GET /api/auth/me
// Returns the authenticated user + their company's brand colour
router.get("/me", async (req, res) => {
  if (!req.session?.userId) {
    return res.status(401).json({ error: "Not authenticated" });
  }

  try {
    // ── Example with raw pg / drizzle ──────────────────────────────────────
    // Adjust table/column names to match your schema.
    const result = await db.query(`
      SELECT
        u.id,
        u.name,
        u.email,
        u.role,
        c.id          AS company_id,
        c.name        AS company_name,
        c.brand_colour                    -- ← include this
      FROM users u
      JOIN companies c ON c.id = u.company_id
      WHERE u.id = $1
      LIMIT 1
    `, [req.session.userId]);

    const row = result.rows[0];
    if (!row) return res.status(404).json({ error: "User not found" });

    return res.json({
      id:    row.id,
      name:  row.name,
      email: row.email,
      role:  row.role,
      company: {
        id:           row.company_id,
        name:         row.company_name,
        brand_colour: row.brand_colour ?? null,
      },
    });

  } catch (err) {
    console.error("[GET /api/auth/me]", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;


// ─────────────────────────────────────────────────────────────────────────────
// PATCH /api/admin/companies/:id/branding
// Allows the Platform Admin (Rick) to set a company's brand colour.
// ─────────────────────────────────────────────────────────────────────────────

router.patch("/admin/companies/:id/branding", async (req, res) => {
  // Guard: only super admins can set company branding
  if (req.session?.role !== "super_admin") {
    return res.status(403).json({ error: "Forbidden" });
  }

  const { id } = req.params;
  const { brand_colour } = req.body as { brand_colour: string };

  // Validate hex format
  if (!/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(brand_colour)) {
    return res.status(400).json({ error: "Invalid hex colour. Expected #rrggbb or #rgb." });
  }

  try {
    await db.query(
      `UPDATE companies SET brand_colour = $1 WHERE id = $2`,
      [brand_colour, id]
    );
    return res.json({ success: true, brand_colour });
  } catch (err) {
    console.error("[PATCH /api/admin/companies/:id/branding]", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});
