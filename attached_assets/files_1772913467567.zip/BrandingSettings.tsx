// components/admin/BrandingSettings.tsx
// A colour picker panel for the Platform Admin to set each company's brand colour.
// Drop this into your existing company detail/edit page in the admin panel.

import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Palette, Check, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

// ── Preset brand colours for quick selection ──────────────────────────────
const PRESET_COLOURS = [
  { label: "GT Blue",    hex: "#2563eb" },
  { label: "Slate",      hex: "#475569" },
  { label: "Red",        hex: "#dc2626" },
  { label: "Green",      hex: "#16a34a" },
  { label: "Orange",     hex: "#ea580c" },
  { label: "Purple",     hex: "#7c3aed" },
  { label: "Teal",       hex: "#0d9488" },
  { label: "Rose",       hex: "#e11d48" },
  { label: "Indigo",     hex: "#4338ca" },
  { label: "Amber",      hex: "#d97706" },
];

// ── Zod schema ────────────────────────────────────────────────────────────
const brandingSchema = z.object({
  brand_colour: z
    .string()
    .regex(/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/, "Must be a valid hex colour (#rrggbb)"),
});
type BrandingForm = z.infer<typeof brandingSchema>;

// ── Props ─────────────────────────────────────────────────────────────────
interface BrandingSettingsProps {
  companyId: number;
  companyName: string;
  currentColour: string | null;
}

// ── Component ─────────────────────────────────────────────────────────────
export function BrandingSettings({ companyId, companyName, currentColour }: BrandingSettingsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [preview, setPreview] = useState<string>(currentColour ?? "#2563eb");

  const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm<BrandingForm>({
    resolver: zodResolver(brandingSchema),
    defaultValues: { brand_colour: currentColour ?? "#2563eb" },
  });

  const colour = watch("brand_colour");

  // ── Mutation ────────────────────────────────────────────────────────────
  const mutation = useMutation({
    mutationFn: async (data: BrandingForm) => {
      const res = await fetch(`/api/admin/companies/${companyId}/branding`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error ?? "Failed to update branding");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["companies", companyId] });
      queryClient.invalidateQueries({ queryKey: ["auth", "me"] });
      toast({ title: "Branding updated", description: `${companyName}'s brand colour has been saved.` });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  function selectPreset(hex: string) {
    setValue("brand_colour", hex, { shouldValidate: true });
    setPreview(hex);
  }

  function onSubmit(data: BrandingForm) {
    mutation.mutate(data);
  }

  // Keep preview in sync with typed input
  function handleColourInput(e: React.ChangeEvent<HTMLInputElement>) {
    const val = e.target.value;
    if (/^#([0-9a-fA-F]{0,6})$/.test(val)) {
      setPreview(val.length >= 4 ? val : preview);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Palette className="w-4 h-4" />
          Company Branding
        </CardTitle>
        <CardDescription>
          Set a brand colour for <strong>{companyName}</strong>. This colour will theme their
          GuardTrack dashboard — sidebar accents, buttons, badges, and background tints.
        </CardDescription>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">

          {/* ── Live Preview ── */}
          <div
            className="rounded-xl p-4 flex items-center gap-4 border transition-all duration-300"
            style={{
              background: `linear-gradient(135deg, ${preview}22 0%, ${preview}08 100%)`,
              borderColor: `${preview}44`,
            }}
          >
            <div
              className="w-12 h-12 rounded-xl flex-shrink-0 shadow-lg transition-all duration-300"
              style={{ background: preview, boxShadow: `0 4px 16px ${preview}55` }}
            />
            <div>
              <p className="text-sm font-semibold text-foreground">{companyName}</p>
              <p className="text-xs text-muted-foreground">Brand preview</p>
              <p className="text-xs font-mono mt-1" style={{ color: preview }}>{preview}</p>
            </div>
            <div className="ml-auto flex gap-2">
              <div
                className="px-3 py-1 rounded-full text-xs font-semibold text-white transition-all duration-300"
                style={{ background: preview }}
              >
                Button
              </div>
              <div
                className="px-3 py-1 rounded-full text-xs font-semibold transition-all duration-300"
                style={{ background: `${preview}22`, color: preview, border: `1px solid ${preview}44` }}
              >
                Badge
              </div>
            </div>
          </div>

          {/* ── Preset Swatches ── */}
          <div>
            <Label className="text-xs text-muted-foreground mb-2 block">Quick select</Label>
            <div className="flex flex-wrap gap-2">
              {PRESET_COLOURS.map((p) => (
                <button
                  key={p.hex}
                  type="button"
                  onClick={() => selectPreset(p.hex)}
                  title={p.label}
                  className="w-8 h-8 rounded-lg border-2 transition-all duration-150 hover:scale-110 focus:outline-none"
                  style={{
                    background: p.hex,
                    borderColor: colour === p.hex ? "white" : "transparent",
                    boxShadow: colour === p.hex ? `0 0 0 2px ${p.hex}` : "none",
                  }}
                >
                  {colour === p.hex && <Check className="w-3 h-3 text-white mx-auto" />}
                </button>
              ))}
            </div>
          </div>

          {/* ── Hex Input + Native Colour Picker ── */}
          <div className="flex gap-3 items-end">
            <div className="flex-1">
              <Label htmlFor="brand_colour">Hex colour code</Label>
              <Input
                id="brand_colour"
                placeholder="#2563eb"
                {...register("brand_colour")}
                onChange={(e) => {
                  register("brand_colour").onChange(e);
                  handleColourInput(e);
                }}
                className="font-mono"
              />
              {errors.brand_colour && (
                <p className="text-xs text-destructive mt-1">{errors.brand_colour.message}</p>
              )}
            </div>
            {/* Native colour picker as a visual aid */}
            <div>
              <Label className="block mb-1 text-xs text-muted-foreground">Picker</Label>
              <input
                type="color"
                value={preview}
                onChange={(e) => selectPreset(e.target.value)}
                className="w-10 h-10 rounded-lg border border-input cursor-pointer p-0.5"
              />
            </div>
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => selectPreset("#2563eb")}
              title="Reset to GuardTrack default"
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
          </div>

          {/* ── Save ── */}
          <Button
            type="submit"
            disabled={mutation.isPending || !!errors.brand_colour}
            className="w-full transition-all duration-300"
            style={{ background: preview, boxShadow: `0 4px 14px ${preview}55` }}
          >
            {mutation.isPending ? "Saving..." : "Save Brand Colour"}
          </Button>

        </form>
      </CardContent>
    </Card>
  );
}
