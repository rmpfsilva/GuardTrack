// tailwind.config.ts — ADDITIONS ONLY
// Merge these into your existing tailwind.config.ts
// This lets you use classes like: bg-brand, text-brand-dark, border-brand-light, etc.

import type { Config } from "tailwindcss";

const config: Config = {
  // ... your existing config (content, darkMode, plugins, etc.) ...

  theme: {
    extend: {
      // ... your existing theme extensions ...

      colors: {
        // Per-company brand colours — driven by CSS variables set by useCompanyTheme
        brand: {
          DEFAULT:      "var(--brand)",
          dark:         "var(--brand-dark)",
          light:        "var(--brand-light)",
          mid:          "var(--brand-mid)",
          glow:         "var(--brand-glow)",
          "glow-strong":"var(--brand-glow-strong)",
        },
      },

      boxShadow: {
        brand:       "0 4px 14px var(--brand-glow-strong)",
        "brand-sm":  "0 2px 8px var(--brand-glow)",
      },

      backgroundImage: {
        // Reusable gradient helpers
        "brand-gradient": "linear-gradient(135deg, var(--brand) 0%, var(--brand-mid) 100%)",
        "brand-wash":     "radial-gradient(ellipse 60% 50% at 70% 20%, var(--brand-glow) 0%, transparent 70%)",
      },
    },
  },
};

export default config;

// ─────────────────────────────────────────────────────────────────────────────
// USAGE EXAMPLES in your components:
//
//  Background tint:        className="bg-brand-light"
//  Solid brand bg:         className="bg-brand"
//  Brand text colour:      className="text-brand"
//  Dark brand text:        className="text-brand-dark"
//  Brand border:           className="border border-brand"
//  Glow shadow:            className="shadow-brand"
//  Gradient button:        className="bg-brand-gradient"
// ─────────────────────────────────────────────────────────────────────────────
